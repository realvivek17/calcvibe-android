# CalcVibe by Vivek Singh — Android MVP

CalcVibe is a native Kotlin Android calculator designed around a large, readable keypad and a separate, organized collection of everyday finance tools. It starts directly into the calculator screen and makes no network requests.

## Features in this first build

- Large calculator keypad with operator preview, backspace, sign toggle, percent, memory keys and undo/redo.
- Light and dark themes; USD is the default display currency for the American client, and INR can be selected from the top-bar currency chip.
- Offline smart calculation input for supported natural-language math and finance questions.
- Tax/GST, discount, simple interest, compound interest, loan EMI, reverse percentage, profit/loss, percentage change, bill split, unit price comparison, unit conversion, savings growth and a monthly budget snapshot.
- Local history with category, date/time, calculation details, copy/share, delete, clear-all and reuse of previous calculations.
- Indian rupee formatting and Indian lakh/crore amount recognition.
- No ad SDK, no analytics SDK, no Internet permission and no unnecessary permissions. App data backup is disabled.
- No music or background audio.

## Important scope note

The smart input is a local rule-based calculator helper—not an unrestricted general-purpose AI chatbot. It recognizes a defined set of common maths/finance requests. When input is ambiguous or unsupported, it asks for a clearer format instead of inventing an answer. A general AI assistant would require a separate model/API and careful privacy/cost decisions; it is not enabled in this offline first build.

Financial calculators provide arithmetic estimates. EMI depends on the rate and tenure supplied; actual lender fees, tax rules, loan terms and investment returns may differ. This app does not provide tax, lending or investment advice.

## Build

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin: 2.0.21
- JDK: 17
- Compile/target SDK: 35
- Minimum SDK: 23

Run:

```bash
gradle testDebugUnitTest --no-daemon
gradle assembleDebug --no-daemon
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

The repository includes `.github/workflows/android.yml`, which runs the unit tests and builds the debug APK on push or manual workflow dispatch. It uploads the APK as a GitHub Actions artifact named `calcvibe-debug-apk`.

## Local storage

Calculation history and memory are stored in Android SharedPreferences on the device. Clearing app data or uninstalling the app removes them. Clearing history from the History screen removes saved calculations without affecting the installed app.
