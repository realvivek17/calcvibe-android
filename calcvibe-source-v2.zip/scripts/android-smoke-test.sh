#!/usr/bin/env bash
set +e
mkdir -p diagnostics
adb wait-for-device
adb shell settings put system font_scale 1.0 >/dev/null 2>&1
adb logcat -c
adb install -r app/build/outputs/apk/debug/app-debug.apk > diagnostics/install.txt 2>&1
install_status=$?
if [ "$install_status" -ne 0 ]; then
  adb logcat -d -v threadtime > diagnostics/logcat.txt
  echo "APK installation failed ($install_status)."
  exit "$install_status"
fi
adb shell am force-stop com.calcvibe.app
adb shell am start -W -n com.calcvibe.app/.MainActivity > diagnostics/start.txt 2>&1
start_status=$?
sleep 7
adb logcat -d -v threadtime > diagnostics/logcat.txt
adb exec-out screencap -p > diagnostics/startup.png 2>/dev/null
adb shell uiautomator dump /sdcard/calcvibe-window.xml > diagnostics/uiautomator.txt 2>&1
adb pull /sdcard/calcvibe-window.xml diagnostics/window.xml >/dev/null 2>&1
adb shell pidof com.calcvibe.app > diagnostics/pid.txt 2>/dev/null

echo '--- Activity launch ---'
cat diagnostics/start.txt
echo '--- Fatal log summary ---'
grep -E 'FATAL EXCEPTION|Fatal signal|Process: com\.calcvibe\.app|Caused by:|ANR in com\.calcvibe\.app' diagnostics/logcat.txt | tail -60 || true

python3 - <<'PY'
import os, re, sys, time, subprocess, xml.etree.ElementTree as ET
p='diagnostics/window.xml'
if not os.path.exists(p) or os.path.getsize(p)==0:
    print('Keypad smoke test failed: UI hierarchy was not captured.')
    sys.exit(4)
try:
    root=ET.parse(p).getroot()
except Exception as e:
    print('Keypad smoke test failed: could not parse UI hierarchy:', e)
    sys.exit(4)

def center_for(desc):
    for node in root.iter('node'):
        if node.attrib.get('content-desc') == desc:
            bounds=node.attrib.get('bounds','')
            m=re.fullmatch(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', bounds)
            if m:
                x1,y1,x2,y2=map(int,m.groups())
                return ((x1+x2)//2,(y1+y2)//2)
    return None
sequence=['7','Multiply','2','Calculate']
coords=[center_for(label) for label in sequence]
if any(c is None for c in coords):
    print('Keypad smoke test failed: calculator controls missing from accessibility tree.', sequence, coords)
    sys.exit(4)
for x,y in coords:
    subprocess.run(['adb','shell','input','tap',str(x),str(y)],check=False)
    time.sleep(0.35)
time.sleep(1)
subprocess.run(['adb','shell','uiautomator','dump','/sdcard/calcvibe-result.xml'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
subprocess.run(['adb','pull','/sdcard/calcvibe-result.xml','diagnostics/result.xml'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
try:
    result_root=ET.parse('diagnostics/result.xml').getroot()
    labels=[node.attrib.get('text','') for node in result_root.iter('node')]
    if '14' not in labels:
        print('Keypad smoke test failed: expected result 14 after 7 × 2 =; visible text:', labels[:80])
        sys.exit(3)
    print('Keypad smoke test passed: 7 × 2 = 14.')
except Exception as e:
    print('Could not verify keypad result:',e)
    sys.exit(3)
PY
keypad_status=$?
adb logcat -d -v threadtime > diagnostics/logcat.txt
if grep -E 'FATAL EXCEPTION|Fatal signal|ANR in com\.calcvibe\.app' diagnostics/logcat.txt >/dev/null; then
  echo 'Startup smoke test failed: Android logged a fatal exception/ANR.'
  exit 1
fi
adb shell pidof com.calcvibe.app > diagnostics/pid.txt 2>/dev/null
if [ ! -s diagnostics/pid.txt ]; then
  echo 'Startup smoke test failed: CalcVibe process is not alive after launch.'
  exit 1
fi
if [ "$start_status" -ne 0 ]; then
  echo "Activity start command returned $start_status. See diagnostics/start.txt."
  exit "$start_status"
fi
if [ "$keypad_status" -ne 0 ]; then
  exit "$keypad_status"
fi
echo 'CalcVibe launch smoke test passed.'
