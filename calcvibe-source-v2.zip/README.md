# CalcVibe by Vivek Singh — Android project

CalcVibe is a native Kotlin Android calculator project designed for offline use. The UI uses native Android views to keep launch and interaction responsive without an embedded web runtime.

## Included
- Large responsive basic calculator keypad with arithmetic precedence, brackets, percentage convention, sign toggle, memory, undo and redo.
- Soft liquid-glass tap feedback: radial ripple + translucent top sheen + subtle press/release scale animation.
- Short, low-volume, locally packaged tap sound effect and a visible SFX on/off switch; no music.
- Offline common-language arithmetic and finance prompts. This is a constrained calculator interpreter, not a general-purpose AI chatbot.
- Tax/GST, discount, percentage change, simple/compound interest, EMI, reverse percentage, profit/loss, bill split, unit conversion, price comparison, savings growth and budget snapshot.
- On-device calculation history and local preferences. The manifest declares no internet permission.
- Startup failure guard that logs an exception and presents a copyable diagnostic instead of silently abandoning the screen for failures caught during initial rendering.
- Android emulator smoke-test script that launches the activity, captures logcat/screenshot and tests `7 × 2 = 14`.

## Build requirements
- JDK 17
- Android SDK platform 35 and build tools 35.0.0
- Gradle 8.9

This source package does not include a Gradle wrapper, so the GitHub Actions workflow provisions Gradle 8.9 explicitly.

## Test status
The pure Kotlin calculation engine was compiled locally with `kotlinc`. This environment does not have Android SDK/emulator components, so a full APK build and UI launch must be verified by the included GitHub Actions workflow. Do not label an APK as device-tested until the emulator smoke test passes and a real phone test has been completed.
