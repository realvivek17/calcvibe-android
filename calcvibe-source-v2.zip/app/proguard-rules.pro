# CalcVibe v1.0 does not require custom ProGuard rules.
