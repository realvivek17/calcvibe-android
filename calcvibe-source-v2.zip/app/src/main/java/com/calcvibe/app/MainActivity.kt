package com.calcvibe.app

import android.app.AlertDialog
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

class MainActivity : Activity() {
    private val preferences by lazy { getSharedPreferences("calcvibe_local", MODE_PRIVATE) }
    private var darkMode = true
    private var soundEnabled = true
    private var tapSoundPool: SoundPool? = null
    private var tapSoundId = 0
    private var tapSoundLoaded = false
    private var currencyCode = "USD"
    private var currentTab = "calc"
    private var currentToolId: String? = null
    private var expression = ""
    private var previousAnswer = "0"
    private var memoryValue = 0.0
    private var smartQuery = ""
    private var lastSmartAnswer: CalcEngine.SmartAnswer? = null
    private val undoStack = mutableListOf<String>()
    private val redoStack = mutableListOf<String>()
    private var toolPrefillId: String? = null
    private var toolPrefillValues: List<String> = emptyList()
    private val history = mutableListOf<HistoryEntry>()

    private lateinit var shell: LinearLayout
    private lateinit var contentFrame: FrameLayout
    private lateinit var calcExpressionView: TextView
    private lateinit var calcAnswerView: TextView
    private lateinit var navCalc: TextView
    private lateinit var navTools: TextView
    private lateinit var navHistory: TextView

    private data class HistoryEntry(
        val id: Long,
        val title: String,
        val input: String,
        val result: String,
        val details: String,
        val category: String,
        val timestamp: Long
    )

    private data class FieldSpec(val label: String, val hint: String, val defaultValue: String = "")
    private data class ToolSpec(val id: String, val title: String, val description: String, val symbol: String, val fields: List<FieldSpec>)

    private val tools by lazy {
        listOf(
            ToolSpec("smart", "Ask CalcVibe", "Type a calculation in plain language", "✳", listOf(FieldSpec("Your calculation", "e.g. 11% tax on 1 lakh"))),
            ToolSpec("tax", "Tax & GST", "Tax amount and final total", "%", listOf(FieldSpec("Base amount (₹)", "100000"), FieldSpec("Tax rate (%)", "11"))),
            ToolSpec("discount", "Discount", "Savings and final price", "−", listOf(FieldSpec("Original price (₹)", "1500"), FieldSpec("Discount (%)", "20"))),
            ToolSpec("change", "Percentage change", "Compare old and new values", "%↗", listOf(FieldSpec("Old value", "20000"), FieldSpec("New value", "24000"))),
            ToolSpec("simple", "Simple interest", "Interest and maturity amount", "SI", listOf(FieldSpec("Principal (₹)", "100000"), FieldSpec("Annual rate (%)", "11"), FieldSpec("Time (years)", "2"))),
            ToolSpec("compound", "Compound interest", "Growth with annual compounding", "CI", listOf(FieldSpec("Principal (₹)", "100000"), FieldSpec("Annual rate (%)", "8"), FieldSpec("Time (years)", "5"))),
            ToolSpec("emi", "Loan EMI", "Monthly payment and total interest", "EMI", listOf(FieldSpec("Loan amount (₹)", "500000"), FieldSpec("Annual interest (%)", "9"), FieldSpec("Duration (years)", "5"))),
            ToolSpec("reverse", "Reverse percentage", "Find original price before discount", "↗", listOf(FieldSpec("Final price after discount (₹)", "1200"), FieldSpec("Discount (%)", "20"))),
            ToolSpec("profit", "Profit & loss", "Profit, loss and selling margin", "±", listOf(FieldSpec("Cost price (₹)", "800"), FieldSpec("Selling price (₹)", "1000"))),
            ToolSpec("bill", "Split a bill", "Divide a bill including an optional tip", "÷", listOf(FieldSpec("Bill total (₹)", "2400"), FieldSpec("People", "4"), FieldSpec("Tip (%)", "0"))),
            ToolSpec("units", "Unit converter", "Convert everyday length and weight units", "⇄", listOf(FieldSpec("Conversion", "e.g. 12 feet to metres"))),
            ToolSpec("compare", "Price compare", "Find the better unit price", "⇆", listOf(FieldSpec("Option A price (₹)", "180"), FieldSpec("Option A quantity", "750"), FieldSpec("Option B price (₹)", "240"), FieldSpec("Option B quantity", "1000"))),
            ToolSpec("savings", "Savings growth", "Estimate monthly saving growth", "↗", listOf(FieldSpec("Monthly contribution (₹)", "2000"), FieldSpec("Annual return (%)", "8"), FieldSpec("Years", "5"))),
            ToolSpec("budget", "Budget snapshot", "Income, expenses and monthly balance", "₹", listOf(FieldSpec("Monthly income (₹)", "40000"), FieldSpec("Essentials (₹)", "18000"), FieldSpec("Lifestyle (₹)", "7000"), FieldSpec("Other expenses (₹)", "3000")))
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Pick the matching system/splash theme before Activity setup to avoid a white flash on cold launch.
        val initialDarkMode = getSharedPreferences("calcvibe_local", MODE_PRIVATE).getBoolean("dark_mode", true)
        setTheme(if (initialDarkMode) R.style.AppThemeDark else R.style.AppTheme)
        super.onCreate(savedInstanceState)
        try {
            darkMode = preferences.getBoolean("dark_mode", true)
            soundEnabled = preferences.getBoolean("tap_sound_enabled", true)
            currencyCode = preferences.getString("currency", "USD") ?: "USD"
            CalcEngine.currencyCode = currencyCode
            memoryValue = preferences.getString("memory", "0")?.toDoubleOrNull() ?: 0.0
            readHistory()
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            prepareTapSound()
            renderApp()
        } catch (error: Exception) {
            showStartupFailure(error)
        }
    }

    private fun renderApp() {
        applySystemBars()
        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colorBg())
            fitsSystemWindows = true
        }
        shell.addView(buildHeader(), LinearLayout.LayoutParams(-1, dp(62)))
        contentFrame = FrameLayout(this)
        shell.addView(contentFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        shell.addView(buildBottomNav(), LinearLayout.LayoutParams(-1, dp(62)))
        setContentView(shell)
        renderContent()
        renderNavState()
    }

    private fun applySystemBars() {
        window.statusBarColor = colorBg()
        window.navigationBarColor = colorBg()
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val controller = window.insetsController
            if (controller != null) {
                val flags = if (darkMode) 0 else android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                controller.setSystemBarsAppearance(flags, android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS)
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (darkMode) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(5), dp(16), dp(5))
            setBackgroundColor(colorBg())
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(text("CalcVibe", 22f, colorText(), true), LinearLayout.LayoutParams(-2, -2))
        val sub = text("by Vivek Singh", 11f, colorMuted(), false)
        sub.letterSpacing = 0.035f
        brand.addView(sub, LinearLayout.LayoutParams(-2, -2))
        row.addView(brand, LinearLayout.LayoutParams(0, -1, 1f))
        run {
            val undo = text("↶", 23f, colorText(), true).apply {
                gravity = Gravity.CENTER
                background = roundRect(colorSurface(), 16f)
                contentDescription = "Undo"
                isClickable = true
                setOnClickListener { performUndo() }
            }
            applyLiquidFeedback(undo, 16f)
            row.addView(undo, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(5) })
            val redo = text("↷", 23f, colorText(), true).apply {
                gravity = Gravity.CENTER
                background = roundRect(colorSurface(), 16f)
                contentDescription = "Redo"
                isClickable = true
                setOnClickListener { performRedo() }
            }
            applyLiquidFeedback(redo, 16f)
            row.addView(redo, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(7) })
        }
        val currency = text(currencyCode, 11f, colorText(), true).apply {
            gravity = Gravity.CENTER
            background = roundRect(colorSurface(), 16f)
            contentDescription = "Choose display currency"
            isClickable = true
            isFocusable = true
            setOnClickListener { showCurrencyPicker() }
        }
        applyLiquidFeedback(currency, 16f)
        row.addView(currency, LinearLayout.LayoutParams(dp(44), dp(40)).apply { marginEnd = dp(5) })
        val sfx = text(if (soundEnabled) "SFX" else "OFF", 10f, if (soundEnabled) colorAccent() else colorMuted(), true).apply {
            gravity = Gravity.CENTER
            background = roundRect(colorSurface(), 14f)
            contentDescription = if (soundEnabled) "Turn tap sounds off" else "Turn tap sounds on"
            isClickable = true
            isFocusable = true
            setOnClickListener {
                soundEnabled = !soundEnabled
                preferences.edit().putBoolean("tap_sound_enabled", soundEnabled).apply()
                text = if (soundEnabled) "SFX" else "OFF"
                setTextColor(if (soundEnabled) colorAccent() else colorMuted())
                contentDescription = if (soundEnabled) "Turn tap sounds off" else "Turn tap sounds on"
                if (soundEnabled) playTapSound()
            }
        }
        applyLiquidFeedback(sfx, 14f, playSound = false)
        row.addView(sfx, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(5) })
        val theme = text(if (darkMode) "☼" else "☾", 24f, colorText(), true).apply {
            gravity = Gravity.CENTER
            background = roundRect(colorSurface(), 18f)
            contentDescription = "Toggle appearance"
            isClickable = true
            isFocusable = true
            setOnClickListener {
                darkMode = !darkMode
                preferences.edit().putBoolean("dark_mode", darkMode).apply()
                recreate()
            }
        }
        applyLiquidFeedback(theme, 18f)
        row.addView(theme, LinearLayout.LayoutParams(dp(44), dp(44)))
        return row
    }

    private fun buildBottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            setBackgroundColor(colorBg())
        }
        navCalc = navItem("⌗", "Calculator") { currentTab = "calc"; currentToolId = null; renderContent(); renderNavState() }
        navTools = navItem("▦", "Tools") { currentTab = "tools"; currentToolId = null; renderContent(); renderNavState() }
        navHistory = navItem("◷", "History") { currentTab = "history"; currentToolId = null; renderContent(); renderNavState() }
        nav.addView(navCalc, LinearLayout.LayoutParams(0, -1, 1f))
        nav.addView(navTools, LinearLayout.LayoutParams(0, -1, 1f))
        nav.addView(navHistory, LinearLayout.LayoutParams(0, -1, 1f))
        return nav
    }

    private fun navItem(symbol: String, label: String, action: () -> Unit): TextView = text("$symbol\n$label", 11f, colorMuted(), true).apply {
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
        applyLiquidFeedback(this, 18f)
    }

    private fun renderNavState() {
        if (!::navCalc.isInitialized) return
        val selected = if (currentTab == "calc") navCalc else if (currentTab == "tools") navTools else navHistory
        listOf(navCalc, navTools, navHistory).forEach {
            it.setTextColor(if (it === selected) colorAccent() else colorMuted())
            it.background = if (it === selected) roundRect(colorAccentSoft(), 18f) else roundRect(colorBg(), 18f)
        }
    }

    private fun renderContent() {
        contentFrame.removeAllViews()
        val view = when (currentTab) {
            "tools" -> if (currentToolId == null) buildToolsPage() else buildToolDetail(currentToolId!!)
            "history" -> buildHistoryPage()
            else -> buildCalculatorPage()
        }
        contentFrame.addView(view, FrameLayout.LayoutParams(-1, -1))
        renderNavState()
    }

    private fun buildCalculatorPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(5), dp(14), dp(7))
            setBackgroundColor(colorBg())
        }

        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(18), dp(12), dp(18), dp(13))
            background = roundRect(colorSurface(), 26f)
            minimumHeight = dp(82)
        }
        calcExpressionView = text(if (lastSmartAnswer != null && expression.isEmpty()) lastSmartAnswer!!.title else displayExpression(expression), 18f, colorMuted(), false).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 2
        }
        calcAnswerView = text(if (lastSmartAnswer != null && expression.isEmpty()) lastSmartAnswer!!.summary else displayAnswer(), 34f, colorText(), true).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 2
            if (android.os.Build.VERSION.SDK_INT >= 26) setAutoSizeTextTypeWithDefaults(TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM)
        }
        display.addView(calcExpressionView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(calcAnswerView, LinearLayout.LayoutParams(-1, -2))
        page.addView(display, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(8) })

        val queryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val query = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            setTextColor(colorText())
            setHintTextColor(colorMuted())
            hint = "Try: 11% tax on 1 lakh"
            setPadding(dp(14), 0, dp(8), 0)
            background = roundRect(colorSurface(), 17f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_DONE
            setText(smartQuery)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { smartQuery = s?.toString() ?: "" }
                override fun afterTextChanged(s: Editable?) = Unit
            })
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) { solveSmartQuery(smartQuery); true } else false
            }
        }
        queryRow.addView(query, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(7) })
        queryRow.addView(pillButton("Solve", colorAccent(), Color.WHITE) { solveSmartQuery(smartQuery) }, LinearLayout.LayoutParams(dp(76), dp(46)))
        page.addView(queryRow, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(7) })

        val memoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("MC", "M+", "M−", "MR").forEachIndexed { index, label ->
            val tv = text(label, 13f, colorMuted(), true).apply {
                gravity = Gravity.CENTER
                background = roundRect(colorSurface(), 15f)
                isClickable = true
                setOnClickListener { handleMemory(index) }
            }
            applyLiquidFeedback(tv, 15f)
            memoryRow.addView(tv, LinearLayout.LayoutParams(0, dp(31), 1f).apply {
                if (index > 0) marginStart = dp(5)
                marginEnd = dp(5)
            })
        }
        page.addView(memoryRow, LinearLayout.LayoutParams(-1, dp(31)).apply { bottomMargin = dp(7) })

        val rows = listOf(
            listOf("AC", "⌫", "±", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("%", "0", ".", "=")
        )
        rows.forEachIndexed { idx, items -> page.addView(keypadRow(items), LinearLayout.LayoutParams(-1, 0, if (idx == rows.lastIndex) 1.15f else 1f).apply { bottomMargin = dp(6) }) }
        return page
    }

    private fun keypadRow(labels: List<String>): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        labels.forEachIndexed { index, label ->
            val isOperator = label in listOf("÷", "×", "−", "+", "=")
            val isAction = label in listOf("AC", "⌫", "±", "%")
            val bg = when {
                label == "=" -> colorAccent()
                isOperator -> colorOperator()
                isAction -> colorAction()
                else -> colorKey()
            }
            val fg = when {
                label == "=" -> Color.WHITE
                isOperator || isAction -> colorAccent()
                else -> colorText()
            }
            val key = text(label, if (label == "AC") 17f else 24f, fg, true).apply {
                gravity = Gravity.CENTER
                background = roundRect(bg, 28f)
                isClickable = true
                isFocusable = true
                contentDescription = when (label) { "⌫" -> "Backspace"; "±" -> "Change sign"; "=" -> "Calculate"; "÷" -> "Divide"; "×" -> "Multiply"; else -> label }
                setOnClickListener { handleKey(label) }
            }
            applyLiquidFeedback(key, 28f)
            row.addView(key, LinearLayout.LayoutParams(0, -1, 1f).apply {
                if (index > 0) marginStart = dp(4)
                marginEnd = dp(4)
            })
        }
        return row
    }

    private fun handleKey(key: String) {
        undoStack.add(expression)
        if (undoStack.size > 60) undoStack.removeAt(0)
        redoStack.clear()
        when (key) {
            "AC" -> { expression = ""; lastSmartAnswer = null; previousAnswer = "0" }
            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); lastSmartAnswer = null }
            "=" -> {
                try {
                    val result = CalcEngine.evaluateExpression(expression)
                    val resultText = CalcEngine.compact(result)
                    addHistory("Basic calculation", expression, resultText, "Expression: ${displayExpression(expression)}\nAnswer: $resultText", "Calculator")
                    previousAnswer = resultText
                    expression = resultText
                    lastSmartAnswer = null
                } catch (e: Exception) { showMessage("Check calculation", e.message ?: "Please check the expression.") }
            }
            "±" -> {
                val match = Regex("(-?\\d+(?:\\.\\d*)?)$").find(expression)
                if (match != null) {
                    val value = match.value
                    val swapped = if (value.startsWith("-")) value.drop(1) else "-$value"
                    expression = expression.substring(0, match.range.first) + swapped
                } else if (expression.isEmpty()) expression = "-"
                lastSmartAnswer = null
            }
            else -> {
                lastSmartAnswer = null
                val actual = when (key) { "×" -> "*"; "÷" -> "/"; "−" -> "-"; else -> key }
                if (actual in listOf("+", "-", "*", "/")) {
                    if (expression.isEmpty() && actual != "-") return
                    if (expression.lastOrNull() in listOf('+', '-', '*', '/')) {
                        expression = expression.dropLast(1) + actual
                    } else expression += actual
                } else if (actual == ".") {
                    val lastToken = expression.split(Regex("[+*/-]")).lastOrNull() ?: ""
                    if (!lastToken.contains('.')) expression += if (expression.isEmpty() || expression.last() in listOf('+','-','*','/')) "0." else "."
                } else expression += actual
            }
        }
        updateDisplay()
    }

    private fun performUndo() {
        if (undoStack.isEmpty()) return
        redoStack.add(expression)
        expression = undoStack.removeAt(undoStack.lastIndex)
        lastSmartAnswer = null
        if (currentTab != "calc") currentTab = "calc"
        renderContent()
    }

    private fun performRedo() {
        if (redoStack.isEmpty()) return
        undoStack.add(expression)
        expression = redoStack.removeAt(redoStack.lastIndex)
        lastSmartAnswer = null
        if (currentTab != "calc") currentTab = "calc"
        renderContent()
    }

    private fun displayExpression(value: String): String = when {
        value.isBlank() -> "Ready when you are"
        else -> value.replace("*", " × ").replace("/", " ÷ ").replace("-", "−").trim()
    }

    private fun displayAnswer(): String {
        if (expression.isBlank()) return "0"
        return try { CalcEngine.number(CalcEngine.evaluateExpression(expression)) } catch (_: Exception) { previousAnswer }
    }

    private fun updateDisplay() {
        if (lastSmartAnswer != null && expression.isEmpty()) {
            calcExpressionView.text = lastSmartAnswer!!.title
            calcAnswerView.text = lastSmartAnswer!!.summary
        } else {
            calcExpressionView.text = displayExpression(expression)
            calcAnswerView.text = displayAnswer()
        }
    }

    private fun handleMemory(action: Int) {
        val current = try { CalcEngine.evaluateExpression(expression) } catch (_: Exception) { previousAnswer.toDoubleOrNull() ?: 0.0 }
        when (action) {
            0 -> memoryValue = 0.0
            1 -> memoryValue += current
            2 -> memoryValue -= current
            3 -> { expression = CalcEngine.compact(memoryValue); lastSmartAnswer = null; updateDisplay() }
        }
        preferences.edit().putString("memory", memoryValue.toString()).apply()
    }

    private fun solveSmartQuery(queryText: String) {
        hideKeyboard()
        try {
            val answer = CalcEngine.solveNaturalLanguage(queryText)
            lastSmartAnswer = answer
            expression = ""
            previousAnswer = answer.numericValue?.let { CalcEngine.compact(it) } ?: answer.summary
            addHistory(answer.title, queryText, answer.summary, answer.details, answer.category)
            renderContent()
            AlertDialog.Builder(this)
                .setTitle(answer.title)
                .setMessage(answer.details)
                .setPositiveButton("Done", null)
                .setNeutralButton("Copy result") { _, _ -> copyText(answer.details) }
                .show()
        } catch (e: Exception) {
            showMessage("Let's clarify that", e.message ?: "Try a simple calculation, tax, discount, interest or EMI question.")
        }
    }

    private fun buildToolsPage(): View {
        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(9), dp(16), dp(20)) }
        column.addView(text("Everyday tools", 25f, colorText(), true), LinearLayout.LayoutParams(-1, -2))
        column.addView(text("Pick a tool. Your calculations stay on this phone.", 13f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(16) })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tools.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            pair.forEach { tool -> row.addView(toolCard(tool), LinearLayout.LayoutParams(0, dp(124), 1f).apply { marginEnd = dp(6); marginStart = dp(6); bottomMargin = dp(12) }) }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(124), 1f))
            grid.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        column.addView(grid, LinearLayout.LayoutParams(-1, -2))
        column.addView(text("Offline note: smart solve handles common calculations. It is not a general-purpose AI chatbot.", 12f, colorMuted(), false).apply { setPadding(dp(6), dp(5), dp(6), dp(10)) })
        scroll.addView(column)
        return scroll
    }

    private fun toolCard(tool: ToolSpec): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(12), dp(12))
            background = roundRect(colorSurface(), 21f)
            isClickable = true
            isFocusable = true
            setOnClickListener { currentToolId = tool.id; renderContent() }
        }
        applyLiquidFeedback(card, 21f)
        card.addView(text(tool.symbol, 22f, colorAccent(), true), LinearLayout.LayoutParams(-1, dp(30)))
        card.addView(text(tool.title, 15f, colorText(), true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        card.addView(text(tool.description, 11f, colorMuted(), false).apply { maxLines = 2 }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        return card
    }

    private fun buildToolDetail(toolId: String): View {
        val spec = tools.firstOrNull { it.id == toolId } ?: return buildToolsPage()
        if (spec.id == "smart" || spec.id == "units") return buildSpecialTool(spec)
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(24)) }
        col.addView(text("‹  All tools", 14f, colorAccent(), true).apply { isClickable = true; setOnClickListener { currentToolId = null; renderContent() } }, LinearLayout.LayoutParams(-1, dp(35)))
        col.addView(text(spec.title, 26f, colorText(), true), LinearLayout.LayoutParams(-1, -2))
        col.addView(text(spec.description, 13f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(18) })
        val inputs = mutableListOf<EditText>()
        spec.fields.forEachIndexed { fieldIndex, field ->
            col.addView(text(field.label.replace("₹", currencySymbol()), 13f, colorText(), true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            val input = EditText(this).apply {
                setSingleLine(true)
                textSize = 16f
                setTextColor(colorText())
                setHintTextColor(colorMuted())
                hint = field.hint
                val prefill = if (toolPrefillId == spec.id && toolPrefillValues.size == spec.fields.size) toolPrefillValues[fieldIndex] else field.defaultValue
                setText(prefill)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                setPadding(dp(14), dp(2), dp(14), dp(2))
                background = roundRect(colorSurface(), 16f)
                imeOptions = EditorInfo.IME_ACTION_NEXT
            }
            inputs += input
            col.addView(input, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(13) })
        }
        val output = text("Enter values, then calculate.", 15f, colorText(), false).apply { setPadding(dp(15), dp(14), dp(15), dp(14)); background = roundRect(colorSurface(), 18f) }
        col.addView(pillButton("Calculate", colorAccent(), Color.WHITE) {
            try {
                val nums = inputs.mapIndexed { i, input ->
                    input.text.toString().trim().replace(",", "").toDoubleOrNull()
                        ?: if (spec.id == "bill" && i == 2) 0.0 else throw IllegalArgumentException("Enter a valid number for ${spec.fields[i].label.lowercase()}.")
                }
                val answer = calculateTool(spec.id, nums)
                output.text = "${answer.summary}\n\n${answer.details}"
                addHistory(answer.title, spec.fields.zip(nums).joinToString(" · ") { it.first.label.replace("₹", currencySymbol()) + ": " + CalcEngine.compact(it.second) }, answer.summary, answer.details, answer.category)
            } catch (e: Exception) { showMessage("Check the values", e.message ?: "Please enter valid values.") }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(3); bottomMargin = dp(12) })
        col.addView(output, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        col.addView(text("Results are estimates. Check the terms that apply to your situation.", 12f, colorMuted(), false))
        scroll.addView(col)
        return scroll
    }

    private fun buildSpecialTool(spec: ToolSpec): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(18)) }
        root.addView(text("‹  All tools", 14f, colorAccent(), true).apply { isClickable = true; setOnClickListener { currentToolId = null; renderContent() } }, LinearLayout.LayoutParams(-1, dp(35)))
        root.addView(text(spec.title, 26f, colorText(), true), LinearLayout.LayoutParams(-1, -2))
        root.addView(text(spec.description, 13f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(14) })
        root.addView(text(if (spec.id == "units") "Examples: 12 feet to metres · 5 kg to pounds · 2 metres to feet" else "Examples: 11% tax on 1 lakh · 20% discount on 1500 · EMI for 500000 at 9% for 5 years", 12f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val input = EditText(this).apply {
            setText(smartQuery.takeIf { currentToolId == "smart" } ?: "")
            setSingleLine(false)
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(colorText())
            setHintTextColor(colorMuted())
            hint = spec.fields.first().hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = roundRect(colorSurface(), 17f)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(90)).apply { bottomMargin = dp(12) })
        root.addView(pillButton(if (spec.id == "units") "Convert" else "Solve calculation", colorAccent(), Color.WHITE) {
            val typed = input.text.toString().trim()
            if (typed.isEmpty()) { showMessage("Enter something first", "Type a calculation or conversion in the box."); return@pillButton }
            smartQuery = typed
            if (spec.id == "units") {
                val converted = convertUnits(typed)
                if (converted == null) showMessage("Conversion not recognized", "Try 12 feet to metres, 5 kg to pounds, or 2 metres to feet.")
                else {
                    addHistory("Unit conversion", typed, converted, "$typed\n$converted", "Unit conversion")
                    showAnswerDialog("Unit conversion", converted, "$typed\n\n$converted")
                }
            } else solveSmartQuery(typed)
        }, LinearLayout.LayoutParams(-1, dp(50)))
        root.addView(text("No account. No network request. The supported calculation runs on your phone.", 12f, colorMuted(), false).apply { setPadding(0, dp(12), 0, 0) }, LinearLayout.LayoutParams(-1, -2))
        return root
    }

    private fun calculateTool(id: String, n: List<Double>): CalcEngine.SmartAnswer {
        when (id) {
            "tax" -> { require(n[0] >= 0 && n[1] >= 0) { "Amount and tax rate cannot be negative." }; return CalcEngine.tax(n[0], n[1]) }
            "discount" -> { require(n[0] >= 0 && n[1] in 0.0..100.0) { "Use a discount between 0% and 100%." }; return CalcEngine.discount(n[0], n[1]) }
            "change" -> {
                require(n[0] != 0.0) { "The old value must be greater than or less than zero, not zero." }
                val change = n[1] - n[0]
                val pct = change / abs(n[0]) * 100.0
                val label = if (change >= 0) "Increase" else "Decrease"
                return CalcEngine.SmartAnswer("Percentage change", "$label: ${CalcEngine.compact(abs(pct))}%", "Old value: ${CalcEngine.number(n[0])}\nNew value: ${CalcEngine.number(n[1])}\nDifference: ${CalcEngine.number(change)}\nPercentage change: ${CalcEngine.compact(pct)}%", "Percentage change", pct)
            }
            "simple" -> { require(n[0] >= 0 && n[1] >= 0 && n[2] >= 0) { "Values cannot be negative." }; return CalcEngine.simpleInterest(n[0], n[1], n[2]) }
            "compound" -> { require(n[0] >= 0 && n[1] >= 0 && n[2] >= 0) { "Values cannot be negative." }; return CalcEngine.compoundInterest(n[0], n[1], n[2]) }
            "emi" -> { require(n[0] > 0 && n[1] >= 0 && n[2] > 0 && n[2] <= 100) { "Enter a positive loan amount and duration up to 100 years." }; return CalcEngine.emi(n[0], n[1], n[2]) }
            "reverse" -> {
                require(n[0] >= 0 && n[1] in 0.0..99.999999) { "Discount must be at least 0% and less than 100%." }
                val original = n[0] / (1.0 - n[1] / 100.0)
                val saved = original - n[0]
                return CalcEngine.SmartAnswer("Reverse percentage", "Original price: ${CalcEngine.money(original)}", "Final price: ${CalcEngine.money(n[0])}\nDiscount: ${CalcEngine.compact(n[1])}%\nOriginal price: ${CalcEngine.money(original)}\nDiscount amount: ${CalcEngine.money(saved)}", "Reverse percentage", original)
            }
            "profit" -> {
                val diff = n[1] - n[0]
                val margin = if (n[1] == 0.0) 0.0 else diff / n[1] * 100.0
                val label = if (diff >= 0) "Profit" else "Loss"
                return CalcEngine.SmartAnswer("Profit & loss", "$label: ${CalcEngine.money(abs(diff))}", "Cost price: ${CalcEngine.money(n[0])}\nSelling price: ${CalcEngine.money(n[1])}\n$label: ${CalcEngine.money(abs(diff))}\nMargin on selling price: ${CalcEngine.compact(margin)}%", "Profit & loss", diff)
            }
            "bill" -> {
                require(n[0] >= 0 && n[1] >= 1 && n[1] <= 10000 && n[2] >= 0 && n[2] <= 100) { "Use 1–10,000 people and a tip between 0% and 100%." }
                val total = n[0] * (1 + n[2] / 100.0)
                val each = total / n[1].toInt()
                return CalcEngine.SmartAnswer("Split a bill", "${CalcEngine.money(each)} per person", "Bill: ${CalcEngine.money(n[0])}\nTip: ${CalcEngine.money(total - n[0])} (${CalcEngine.compact(n[2])}%)\nTotal: ${CalcEngine.money(total)}\nPeople: ${n[1].toInt()}\nEach person pays: ${CalcEngine.money(each)}", "Bill split", each)
            }
            "compare" -> {
                require(n[0] >= 0 && n[2] >= 0 && n[1] > 0 && n[3] > 0) { "Prices cannot be negative and quantities must be above zero." }
                val a = n[0] / n[1]; val b = n[2] / n[3]
                val cheaper = if (a <= b) "Option A" else "Option B"
                return CalcEngine.SmartAnswer("Price comparison", "$cheaper has the lower unit price", "Option A: ${CalcEngine.money(n[0])} for ${CalcEngine.compact(n[1])} units → ${CalcEngine.money(a)} per unit\nOption B: ${CalcEngine.money(n[2])} for ${CalcEngine.compact(n[3])} units → ${CalcEngine.money(b)} per unit\nBetter value by unit price: $cheaper", "Price comparison", minOf(a,b))
            }
            "savings" -> {
                require(n[0] >= 0 && n[1] >= 0 && n[2] >= 0 && n[2] <= 100) { "Values must be non-negative; duration must be 100 years or less." }
                val months = (n[2] * 12).toInt()
                val monthlyRate = n[1] / 1200.0
                val future = if (monthlyRate == 0.0) n[0] * months else n[0] * ((1 + monthlyRate).pow(months) - 1) / monthlyRate
                val contributed = n[0] * months
                return CalcEngine.SmartAnswer("Savings growth", "Estimated value: ${CalcEngine.money(future)}", "Monthly contribution: ${CalcEngine.money(n[0])}\nDuration: $months months\nTotal contributed: ${CalcEngine.money(contributed)}\nAssumed annual return: ${CalcEngine.compact(n[1])}%\nEstimated future value: ${CalcEngine.money(future)}\n\nIllustration only; returns are not guaranteed.", "Savings growth", future)
            }
            "budget" -> {
                require(n.all { it >= 0.0 && it.isFinite() }) { "Income and expenses must be non-negative numbers." }
                val expenses = n[1] + n[2] + n[3]
                val balance = n[0] - expenses
                val savingsRate = if (n[0] == 0.0) 0.0 else balance / n[0] * 100.0
                val label = if (balance >= 0) "Money left" else "Over budget"
                return CalcEngine.SmartAnswer("Budget snapshot", "$label: ${CalcEngine.money(abs(balance))}", "Monthly income: ${CalcEngine.money(n[0])}\nEssentials: ${CalcEngine.money(n[1])}\nLifestyle: ${CalcEngine.money(n[2])}\nOther expenses: ${CalcEngine.money(n[3])}\nTotal expenses: ${CalcEngine.money(expenses)}\n$label: ${CalcEngine.money(abs(balance))}\nBalance as a share of income: ${CalcEngine.compact(savingsRate)}%", "Budget snapshot", balance)
            }
        }
        throw IllegalArgumentException("This tool is not available yet.")
    }

    private fun convertUnits(raw: String): String? {
        val pattern = Regex("^\\s*(\\d+(?:\\.\\d+)?)\\s*(feet|foot|ft|inches|inch|in|metres?|meters?|m|kilograms?|kgs?|kg|pounds?|lbs?|lb|grams?|g)\\s+to\\s+(feet|foot|ft|inches|inch|in|metres?|meters?|m|kilograms?|kgs?|kg|pounds?|lbs?|lb|grams?|g)\\s*$", RegexOption.IGNORE_CASE)
        val match = pattern.matchEntire(raw) ?: return null
        val value = match.groupValues[1].toDoubleOrNull() ?: return null
        val from = unitType(match.groupValues[2])
        val to = unitType(match.groupValues[3])
        if (from.first != to.first) return "Those units measure different things. Choose two length units or two weight units."
        val base = value * from.second
        val converted = base / to.second
        return "${CalcEngine.compact(value)} ${match.groupValues[2]} = ${CalcEngine.compact(converted)} ${match.groupValues[3]}"
    }

    /** Converts to a common base: metres for length, kilograms for mass. */
    private fun unitType(unitRaw: String): Pair<String, Double> = when (unitRaw.lowercase(Locale.ROOT)) {
        "feet", "foot", "ft" -> "length" to 0.3048
        "inches", "inch", "in" -> "length" to 0.0254
        "metre", "metres", "meter", "meters", "m" -> "length" to 1.0
        "kilogram", "kilograms", "kg", "kgs" -> "mass" to 1.0
        "pound", "pounds", "lb", "lbs" -> "mass" to 0.45359237
        "gram", "grams", "g" -> "mass" to 0.001
        else -> "length" to 1.0
    }

    private fun buildHistoryPage(): View {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(9), dp(16), dp(20)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text("Your history", 25f, colorText(), true))
        labels.addView(text("Saved privately on this phone", 12f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        header.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        if (history.isNotEmpty()) header.addView(pillButton("Clear", colorSurface(), colorAccent()) { confirmClearHistory() }, LinearLayout.LayoutParams(dp(80), dp(38)))
        col.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        if (history.isEmpty()) {
            col.addView(text("◷", 44f, colorAccent(), true).apply { gravity = Gravity.CENTER; setPadding(0, dp(65), 0, dp(8)) })
            col.addView(text("No calculations yet", 18f, colorText(), true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
            col.addView(text("Your successful calculations will appear here. Nothing is uploaded.", 13f, colorMuted(), false).apply { gravity = Gravity.CENTER; setPadding(dp(18), dp(7), dp(18), dp(10)) }, LinearLayout.LayoutParams(-1, -2))
        } else {
            history.forEach { entry ->
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = roundRect(colorSurface(), 18f); setPadding(dp(14), dp(12), dp(14), dp(12)) }
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                titleCol.addView(text(entry.title, 15f, colorText(), true))
                titleCol.addView(text("${entry.category}  ·  ${dateLabel(entry.timestamp)}", 11f, colorMuted(), false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
                top.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
                val delete = text("×", 23f, colorMuted(), true).apply { gravity = Gravity.CENTER; isClickable = true; setOnClickListener { deleteHistory(entry.id); renderContent() } }
                top.addView(delete, LinearLayout.LayoutParams(dp(32), dp(32)))
                card.addView(top, LinearLayout.LayoutParams(-1, -2))
                card.addView(text(entry.result, 17f, colorAccent(), true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
                card.addView(text(entry.input, 12f, colorMuted(), false).apply { maxLines = 2 }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
                actions.addView(pillButton("Details", colorAction(), colorAccent()) { showAnswerDialog(entry.title, entry.result, entry.details) }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(5) })
                actions.addView(pillButton("Use again", colorAction(), colorAccent()) { reuseHistory(entry) }, LinearLayout.LayoutParams(0, dp(34), 1.15f).apply { marginEnd = dp(5) })
                actions.addView(pillButton("Share", colorAction(), colorAccent()) { shareText("${entry.title}\n${entry.input}\n${entry.result}\n\n${entry.details}") }, LinearLayout.LayoutParams(0, dp(34), 0.9f))
                card.addView(actions, LinearLayout.LayoutParams(-1, dp(35)).apply { topMargin = dp(10) })
                col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        }
        scroll.addView(col)
        return scroll
    }

    private fun reuseHistory(entry: HistoryEntry) {
        val toolId = when {
            entry.category.equals("Tax & GST", true) -> "tax"
            entry.category.equals("Discount", true) -> "discount"
            entry.category.equals("Simple Interest", true) -> "simple"
            entry.category.equals("Compound Interest", true) -> "compound"
            entry.category.equals("EMI", true) -> "emi"
            entry.category.equals("Reverse percentage", true) -> "reverse"
            entry.category.equals("Profit & loss", true) -> "profit"
            entry.category.equals("Bill split", true) -> "bill"
            entry.category.equals("Price comparison", true) -> "compare"
            entry.category.equals("Savings growth", true) -> "savings"
            entry.category.equals("Budget snapshot", true) -> "budget"
            entry.category.equals("Percentage change", true) -> "change"
            entry.category.equals("Unit conversion", true) -> "units"
            else -> null
        }
        if (toolId == "units" && !entry.input.contains(" · ")) {
            currentTab = "tools"
            currentToolId = "units"
            smartQuery = entry.input
            renderContent()
            return
        }
        if (toolId != null && entry.input.contains(" · ")) {
            val values = entry.input.split(" · ").map { it.substringAfter(": ", "").trim() }
            val spec = tools.firstOrNull { it.id == toolId }
            if (spec != null && values.size == spec.fields.size) {
                toolPrefillId = toolId
                toolPrefillValues = values
                currentTab = "tools"
                currentToolId = toolId
                renderContent()
                return
            }
        }
        currentTab = "calc"
        currentToolId = null
        lastSmartAnswer = null
        if (entry.category == "Calculator" || entry.category == "Basic calculation") {
            expression = entry.input
        } else {
            smartQuery = entry.input
        }
        renderContent()
    }

    private fun addHistory(title: String, input: String, result: String, details: String, category: String) {
        history.add(0, HistoryEntry(System.currentTimeMillis(), title, input, result, details, category, System.currentTimeMillis()))
        while (history.size > 500) history.removeAt(history.lastIndex)
        persistHistory()
    }

    private fun readHistory() {
        history.clear()
        val raw = preferences.getString("history", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                history.add(HistoryEntry(obj.optLong("id", i.toLong()), obj.optString("title"), obj.optString("input"), obj.optString("result"), obj.optString("details"), obj.optString("category"), obj.optLong("timestamp")))
            }
        } catch (_: Exception) { history.clear() }
    }

    private fun persistHistory() {
        val arr = JSONArray()
        history.forEach { entry ->
            arr.put(JSONObject().apply {
                put("id", entry.id); put("title", entry.title); put("input", entry.input); put("result", entry.result)
                put("details", entry.details); put("category", entry.category); put("timestamp", entry.timestamp)
            })
        }
        preferences.edit().putString("history", arr.toString()).apply()
    }

    private fun deleteHistory(id: Long) { history.removeAll { it.id == id }; persistHistory() }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this).setTitle("Clear all history?")
            .setMessage("This permanently removes saved calculations from this phone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ -> history.clear(); persistHistory(); renderContent() }.show()
    }

    private fun showCurrencyPicker() {
        val options = arrayOf("US Dollar ($) · USD", "Indian Rupee (₹) · INR")
        val codes = arrayOf("USD", "INR")
        val selected = codes.indexOf(currencyCode).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Display currency")
            .setSingleChoiceItems(options, selected) { dialog, which ->
                currencyCode = codes[which]
                CalcEngine.currencyCode = currencyCode
                preferences.edit().putString("currency", currencyCode).apply()
                dialog.dismiss()
                renderApp()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun currencySymbol(): String = when (currencyCode) {
        "INR" -> "₹"
        "EUR" -> "€"
        "GBP" -> "£"
        else -> "$"
    }

    private fun showAnswerDialog(title: String, summary: String, details: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(details.ifBlank { summary })
            .setPositiveButton("Done", null).setNeutralButton("Copy") { _, _ -> copyText(details.ifBlank { summary }) }.show()
    }

    private fun showMessage(title: String, message: String) { AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show() }

    private fun copyText(value: String) {
        val manager = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        manager.setPrimaryClip(android.content.ClipData.newPlainText("CalcVibe result", value))
        android.widget.Toast.makeText(this, "Copied", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun shareText(value: String) {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, value) }
        startActivity(Intent.createChooser(intent, "Share calculation"))
    }

    private fun dateLabel(timestamp: Long): String = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(timestamp))

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(contentFrame.windowToken, 0)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun pillButton(label: String, backgroundColor: Int, foregroundColor: Int, onClick: () -> Unit): TextView = text(label, 14f, foregroundColor, true).apply {
        gravity = Gravity.CENTER
        background = roundRect(backgroundColor, 18f)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        applyLiquidFeedback(this, 18f)
    }

    private fun prepareTapSound() {
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attributes).build()
            tapSoundPool = pool
            pool.setOnLoadCompleteListener { _, sampleId, status ->
                if (sampleId == tapSoundId) tapSoundLoaded = status == 0
            }
            tapSoundId = pool.load(this, R.raw.tap_soft, 1)
        } catch (error: Exception) {
            Log.w("CalcVibe", "Tap sound is unavailable; continuing silently", error)
            tapSoundPool?.release()
            tapSoundPool = null
            tapSoundLoaded = false
        }
    }

    private fun playTapSound() {
        if (!soundEnabled || !tapSoundLoaded || tapSoundId == 0) return
        try {
            // Quiet, short UI click; never music or a long tone.
            tapSoundPool?.play(tapSoundId, 0.24f, 0.24f, 1, 0, 1.0f)
        } catch (error: Exception) {
            Log.w("CalcVibe", "Tap sound playback failed", error)
        }
    }

    /** Native ripple plus a brief translucent top sheen and tiny scale response for a liquid-glass tap. */
    private fun applyLiquidFeedback(view: View, radiusDp: Float, playSound: Boolean = true) {
        val radiusPx = dp(radiusDp.toInt()).toFloat()
        val baseAlpha = if (darkMode) 66 else 54
        val ripple = RippleDrawable(
            ColorStateList.valueOf(Color.argb(baseAlpha, 221, 239, 255)),
            null,
            roundRect(Color.WHITE, radiusDp)
        )
        val sheen = StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_pressed),
                GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.argb(48, 255, 255, 255), Color.argb(16, 255, 255, 255), Color.TRANSPARENT)
                ).apply { cornerRadius = radiusPx }
            )
            addState(
                intArrayOf(),
                GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    cornerRadius = radiusPx
                }
            )
        }
        // The sheen fades immediately when released; RippleDrawable supplies the radial glass-like highlight.
        view.foreground = LayerDrawable(arrayOf(sheen, ripple))
        view.isHapticFeedbackEnabled = true
        view.setOnTouchListener { target, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (playSound) playTapSound()
                    target.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    target.animate().cancel()
                    target.animate().scaleX(0.965f).scaleY(0.965f)
                        .setDuration(65L).setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    target.animate().cancel()
                    target.animate().scaleX(1f).scaleY(1f)
                        .setDuration(170L).setInterpolator(DecelerateInterpolator()).start()
                }
            }
            // Keep returning false so Android still dispatches the click normally.
            false
        }
    }

    private fun showStartupFailure(error: Exception) {
        Log.e("CalcVibe", "Startup UI failed", error)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(15, 17, 22))
        }
        val title = TextView(this).apply {
            text = "CalcVibe couldn't start"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val detailText = "${error.javaClass.simpleName}: ${error.message ?: "No additional message"}"
        root.addView(TextView(this).apply {
            text = "The app stayed open to help diagnose the problem. Copy the diagnostic details and share them with support.\n\n$detailText"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(18))
        }, LinearLayout.LayoutParams(-1, -2))
        val copy = TextView(this).apply {
            text = "COPY DIAGNOSTIC"
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(Color.rgb(239, 63, 78), 16f)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { copyText("CalcVibe startup UI failure\n$detailText\n\n${Log.getStackTraceString(error)}") }
        }
        root.addView(copy, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onDestroy() {
        tapSoundPool?.release()
        tapSoundPool = null
        tapSoundLoaded = false
        super.onDestroy()
    }

    private fun roundRect(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun colorBg() = if (darkMode) Color.rgb(15, 17, 22) else Color.rgb(249, 249, 251)
    private fun colorSurface() = if (darkMode) Color.rgb(26, 29, 36) else Color.rgb(255, 255, 255)
    private fun colorKey() = if (darkMode) Color.rgb(34, 38, 47) else Color.rgb(241, 242, 245)
    private fun colorText() = if (darkMode) Color.rgb(246, 247, 251) else Color.rgb(39, 40, 45)
    private fun colorMuted() = if (darkMode) Color.rgb(151, 157, 169) else Color.rgb(122, 124, 132)
    private fun colorAccent() = Color.rgb(239, 63, 78) // saturated coral accent
    private fun colorOperator() = if (darkMode) Color.rgb(66, 37, 44) else Color.rgb(255, 231, 234)
    private fun colorAction() = if (darkMode) Color.rgb(46, 38, 44) else Color.rgb(255, 241, 243)
    private fun colorAccentSoft() = if (darkMode) Color.rgb(48, 30, 35) else Color.rgb(255, 237, 239)

    override fun onBackPressed() {
        if (currentTab == "tools" && currentToolId != null) {
            currentToolId = null
            renderContent()
        } else if (currentTab != "calc") {
            currentTab = "calc"
            currentToolId = null
            renderContent()
        } else super.onBackPressed()
    }
}
