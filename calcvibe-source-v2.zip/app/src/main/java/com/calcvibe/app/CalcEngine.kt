package com.calcvibe.app

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow

/** Pure Kotlin calculation engine. Kept independent of Android so core maths can be tested directly. */
object CalcEngine {
    // Standalone engine defaults to INR for unit tests; the Android app sets this from the user's currency preference (USD by default).
    var currencyCode: String = "INR"

    data class SmartAnswer(
        val title: String,
        val summary: String,
        val details: String,
        val category: String,
        val numericValue: Double? = null
    )

    fun evaluateExpression(raw: String): Double {
        var expression = raw.trim()
            .replace("×", "*")
            .replace("÷", "/")
            .replace('−', '-')
            .replace("% of ", "* ")
            .replace(",", "")
            .replace("₹", "")
            .replace("$", "")
            .replace(" ", "")

        require(expression.isNotBlank()) { "Enter a calculation first." }
        require(expression.length <= 180) { "This calculation is too long." }
        require(expression.matches(Regex("[0-9+*/().%\\-]+"))) { "Use numbers and + − × ÷ ( ) % only." }

        // Match the everyday calculator convention: 200 + 10% means 210, not 200.1.
        val addPercent = Regex("^(.+)([+-])(\\d+(?:\\.\\d+)?)%$").matchEntire(expression)
        if (addPercent != null) {
            val base = ExpressionParser(addPercent.groupValues[1]).parse()
            val rate = addPercent.groupValues[3].toDouble() / 100.0
            return base + (if (addPercent.groupValues[2] == "+") 1.0 else -1.0) * base * rate
        }
        val multiplyPercent = Regex("^(.+)[*](\\d+(?:\\.\\d+)?)%$").matchEntire(expression)
        if (multiplyPercent != null) {
            return ExpressionParser(multiplyPercent.groupValues[1]).parse() * multiplyPercent.groupValues[2].toDouble() / 100.0
        }
        return ExpressionParser(expression.replace("%", "/100")).parse()
    }

    /** Understands common calculation requests in plain English, without a network or an AI key. */
    fun solveNaturalLanguage(raw: String): SmartAnswer {
        val text = raw.lowercase(Locale.ROOT).trim().replace(",", "").replace("₹", "")
        require(text.isNotBlank()) { "Type a calculation or a question about an amount." }
        require(text.length <= 300) { "Please keep the request under 300 characters." }

        val rates = Regex("(\\d+(?:\\.\\d+)?)\\s*%")
            .findAll(text).map { it.groupValues[1].toDouble() }.toList()
        val amounts = extractAmounts(text)
        val firstRate = rates.firstOrNull()

        val isEmi = text.contains("emi") || text.contains("loan") || text.contains("monthly payment")
        val isCompound = text.contains("compound")
        val isSimpleInterest = text.contains("simple interest")
        val isInterest = text.contains("interest") || text.contains("intrest")
        val isTax = text.contains("tax") || text.contains("gst") || text.contains("vat")
        val isDiscount = text.contains("discount") || text.contains("off")
        val isPercentQuestion = text.contains("% of") || text.contains("percent of") || text.contains("percentage of")

        if (isEmi) {
            require(amounts.isNotEmpty() && firstRate != null) {
                "For EMI, try: EMI for 500000 at 9% for 5 years."
            }
            val principal = amounts[0]
            val years = findDurationYears(text) ?: amounts.drop(1).firstOrNull()
            require(years != null && years > 0.0) { "Add a loan duration, for example ‘for 5 years’." }
            val months = (years * 12.0).toInt().coerceAtLeast(1)
            val monthlyRate = firstRate / 1200.0
            val payment = if (monthlyRate == 0.0) principal / months else {
                principal * monthlyRate * (1.0 + monthlyRate).pow(months) / ((1.0 + monthlyRate).pow(months) - 1.0)
            }
            val total = payment * months
            val interest = total - principal
            return SmartAnswer(
                "Loan EMI", money(payment) + " per month",
                "Loan amount: ${money(principal)}\nAnnual interest: ${compact(firstRate)}%\nTenure: $months months\nMonthly EMI: ${money(payment)}\nTotal repayment: ${money(total)}\nTotal interest: ${money(interest)}\n\nEstimate only. Actual lender fees and terms can change the result.",
                "EMI", payment
            )
        }

        if (isInterest && (isSimpleInterest || isCompound || Regex("\\bfor\\s+\\d+(?:\\.\\d+)?\\s*(years?|yrs?|months?)\\b").containsMatchIn(text))) {
            require(amounts.isNotEmpty() && firstRate != null) {
                "Try: 1 lakh at 11% simple interest for 2 years."
            }
            val principal = amounts[0]
            val years = findDurationYears(text) ?: findDurationMonths(text)?.div(12.0)
            require(years != null && years > 0.0) { "Add a duration, for example ‘for 2 years’." }
            val interest = if (isCompound) principal * (1.0 + firstRate / 100.0).pow(years) - principal else principal * firstRate / 100.0 * years
            val total = principal + interest
            val title = if (isCompound) "Compound Interest" else "Simple Interest"
            return SmartAnswer(
                title, "Interest: ${money(interest)}",
                "Principal: ${money(principal)}\nAnnual rate: ${compact(firstRate)}%\nTime: ${compact(years)} years\nInterest: ${money(interest)}\nTotal amount: ${money(total)}\n\nAssumes the stated annual rate and no extra fees.",
                title, total
            )
        }

        if (isTax && firstRate != null && amounts.isNotEmpty()) {
            val amount = amounts[0]
            if (text.contains("included") || text.contains("inclusive")) {
                val base = amount / (1.0 + firstRate / 100.0)
                val tax = amount - base
                return SmartAnswer(
                    "Tax included", "Included tax: ${money(tax)}",
                    "Amount including tax: ${money(amount)}\nRate: ${compact(firstRate)}%\nAmount before tax: ${money(base)}\nTax component: ${money(tax)}",
                    "Tax & GST", tax
                )
            }
            val tax = amount * firstRate / 100.0
            return SmartAnswer(
                "Tax / GST", "Tax: ${money(tax)} · Total: ${money(amount + tax)}",
                "Base amount: ${money(amount)}\nTax rate: ${compact(firstRate)}%\nTax amount: ${money(tax)}\nTotal including tax: ${money(amount + tax)}",
                "Tax & GST", amount + tax
            )
        }

        if (isDiscount && firstRate != null && amounts.isNotEmpty()) {
            val price = amounts[0]
            val saving = price * firstRate / 100.0
            val finalPrice = price - saving
            return SmartAnswer(
                "Discount", "You pay ${money(finalPrice)}",
                "Original price: ${money(price)}\nDiscount: ${compact(firstRate)}% (${money(saving)})\nFinal price: ${money(finalPrice)}",
                "Discount", finalPrice
            )
        }

        if ((isPercentQuestion || (firstRate != null && text.contains(" of "))) && amounts.isNotEmpty()) {
            val rate = firstRate ?: rates.first()
            val amount = amounts[0]
            val value = amount * rate / 100.0
            return SmartAnswer(
                "Percentage", compact(rate) + "% of ${money(amount)} = ${money(value)}",
                "Amount: ${money(amount)}\nPercentage: ${compact(rate)}%\nCalculation: ${money(amount)} × ${compact(rate)} ÷ 100\nAnswer: ${money(value)}",
                "Percentage", value
            )
        }

        if (text.contains("profit") || text.contains("margin") || text.contains("loss")) {
            require(amounts.size >= 2) { "Try: profit on cost 800 and selling price 1000." }
            val cost = amounts[0]
            val selling = amounts[1]
            val difference = selling - cost
            val margin = if (selling == 0.0) 0.0 else difference / selling * 100.0
            val label = if (difference >= 0) "Profit" else "Loss"
            return SmartAnswer(
                "Profit & Loss", "$label: ${money(kotlin.math.abs(difference))}",
                "Cost price: ${money(cost)}\nSelling price: ${money(selling)}\n$label: ${money(kotlin.math.abs(difference))}\nMargin on selling price: ${compact(margin)}%",
                "Profit & Loss", difference
            )
        }

        // General arithmetic is accepted after natural-language currency/unit words are removed.
        val expressionCandidate = text
            .replace(Regex("\\b(what is|calculate|solve|please|answer|equals|equal to)\\b"), "")
            .replace(Regex("\\b(rupees?|rs|inr|dollars?)\\b"), "")
            .replace(Regex("\\bdivided by\\b"), "/")
            .replace(Regex("\\btimes\\b|\\bmultiplied by\\b"), "*")
            .replace(Regex("\\bplus\\b"), "+")
            .replace(Regex("\\bminus\\b"), "-")
            .replace("percent", "%")
            .replace(" of ", " * ")
            .trim()
        return try {
            val value = evaluateExpression(expressionCandidate)
            SmartAnswer("Calculation", compact(value), "Expression: $expressionCandidate\nAnswer: ${compact(value)}", "Basic calculation", value)
        } catch (_: Exception) {
            throw IllegalArgumentException(
                "I couldn't safely identify that calculation. Try one of these:\n• 11% tax on 1 lakh\n• 20% discount on 1500\n• 1 lakh at 11% simple interest for 2 years\n• EMI for 500000 at 9% for 5 years\n• 250 × 48\n\nThis offline helper understands common calculations; it is not a general-purpose AI chatbot."
            )
        }
    }

    fun tax(amount: Double, rate: Double): SmartAnswer {
        val tax = amount * rate / 100.0
        return SmartAnswer("Tax / GST", "Tax: ${money(tax)} · Total: ${money(amount + tax)}", "Base amount: ${money(amount)}\nRate: ${compact(rate)}%\nTax: ${money(tax)}\nTotal including tax: ${money(amount + tax)}", "Tax & GST", amount + tax)
    }

    fun discount(amount: Double, rate: Double): SmartAnswer {
        val saving = amount * rate / 100.0
        val total = amount - saving
        return SmartAnswer("Discount", "You pay ${money(total)}", "Original price: ${money(amount)}\nDiscount: ${compact(rate)}%\nYou save: ${money(saving)}\nFinal price: ${money(total)}", "Discount", total)
    }

    fun simpleInterest(principal: Double, rate: Double, years: Double): SmartAnswer {
        val interest = principal * rate / 100.0 * years
        val total = principal + interest
        return SmartAnswer("Simple Interest", "Interest: ${money(interest)}", "Principal: ${money(principal)}\nAnnual rate: ${compact(rate)}%\nTime: ${compact(years)} years\nInterest: ${money(interest)}\nTotal: ${money(total)}", "Simple Interest", total)
    }

    fun compoundInterest(principal: Double, rate: Double, years: Double): SmartAnswer {
        val total = principal * (1 + rate / 100.0).pow(years)
        val interest = total - principal
        return SmartAnswer("Compound Interest", "Interest: ${money(interest)}", "Principal: ${money(principal)}\nAnnual rate: ${compact(rate)}%\nTime: ${compact(years)} years\nInterest: ${money(interest)}\nTotal: ${money(total)}\nAssumes annual compounding.", "Compound Interest", total)
    }

    fun emi(principal: Double, annualRate: Double, years: Double): SmartAnswer {
        val months = (years * 12.0).toInt().coerceAtLeast(1)
        val monthlyRate = annualRate / 1200.0
        val monthly = if (monthlyRate == 0.0) principal / months else {
            principal * monthlyRate * (1 + monthlyRate).pow(months) / ((1 + monthlyRate).pow(months) - 1)
        }
        val total = monthly * months
        return SmartAnswer("Loan EMI", "${money(monthly)} per month", "Loan amount: ${money(principal)}\nAnnual rate: ${compact(annualRate)}%\nDuration: $months months\nMonthly EMI: ${money(monthly)}\nTotal repayment: ${money(total)}\nTotal interest: ${money(total - principal)}\nEstimate only; lender fees and terms may change the result.", "EMI", monthly)
    }

    fun money(value: Double): String {
        val symbol = when (currencyCode) {
            "USD" -> "$"
            "INR" -> "₹"
            "EUR" -> "€"
            "GBP" -> "£"
            else -> "$"
        }
        return symbol + number(value)
    }

    fun number(value: Double): String {
        if (!value.isFinite()) return "Undefined"
        val safe = if (kotlin.math.abs(value) < 0.000000005) 0.0 else value
        val us = NumberFormat.getNumberInstance(Locale.US).apply {
            maximumFractionDigits = 8
            minimumFractionDigits = 0
            isGroupingUsed = false
        }.format(safe)
        val negative = us.startsWith("-")
        val unsigned = us.removePrefix("-")
        val pieces = unsigned.split(".", limit = 2)
        val whole = pieces[0]
        val grouped = if (whole.length <= 3) whole else {
            val lastThree = whole.takeLast(3)
            var rest = whole.dropLast(3)
            val groupSize = if (currencyCode == "INR") 2 else 3
            val groups = mutableListOf<String>()
            while (rest.length > groupSize) {
                groups.add(0, rest.takeLast(groupSize))
                rest = rest.dropLast(groupSize)
            }
            if (rest.isNotEmpty()) groups.add(0, rest)
            groups.joinToString(",") + "," + lastThree
        }
        return (if (negative) "-" else "") + grouped + if (pieces.size > 1) "." + pieces[1] else ""
    }

    fun compact(value: Double): String = if (value.isFinite()) {
        val rounded = kotlin.math.round(value * 1_000_000.0) / 1_000_000.0
        rounded.toString().removeSuffix(".0")
    } else "Undefined"

    private fun findDurationYears(text: String): Double? = Regex("\\bfor\\s+(\\d+(?:\\.\\d+)?)\\s*(?:years?|yrs?)\\b|\\b(\\d+(?:\\.\\d+)?)\\s*(?:years?|yrs?)\\b")
        .find(text)?.let { (it.groups[1]?.value ?: it.groups[2]?.value)?.toDoubleOrNull() }

    private fun findDurationMonths(text: String): Double? = Regex("\\bfor\\s+(\\d+(?:\\.\\d+)?)\\s*months?\\b|\\b(\\d+(?:\\.\\d+)?)\\s*months?\\b")
        .find(text)?.let { (it.groups[1]?.value ?: it.groups[2]?.value)?.toDoubleOrNull() }

    private fun extractAmounts(text: String): List<Double> {
        val regex = Regex("(?<![\\w.])(\\d+(?:\\.\\d+)?)\\s*(crores?|cr|lakhs?|lacs?|lac|k)?", RegexOption.IGNORE_CASE)
        val out = mutableListOf<Double>()
        for (match in regex.findAll(text)) {
            val end = match.range.last + 1
            val after = text.substring(end).trimStart()
            if (after.startsWith("%") || Regex("^(years?|yrs?|months?|percent|percentage)\\b").containsMatchIn(after)) continue
            val n = match.groupValues[1].toDoubleOrNull() ?: continue
            val multiplier = when (match.groupValues[2].lowercase(Locale.ROOT)) {
                "crore", "crores", "cr" -> 10_000_000.0
                "lakh", "lakhs", "lac", "lacs" -> 100_000.0
                "k" -> 1_000.0
                else -> 1.0
            }
            out += n * multiplier
        }
        return out
    }

    private class ExpressionParser(private val source: String) {
        private var position = 0

        fun parse(): Double {
            val result = parseExpression()
            if (position != source.length) error("Unexpected character at position ${position + 1}.")
            require(result.isFinite()) { "The result is not a finite number." }
            require(kotlin.math.abs(result) < 1e100) { "The result is too large." }
            return if (kotlin.math.abs(result) < 0.0000000001) 0.0 else result
        }

        private fun parseExpression(): Double {
            var value = parseTerm()
            while (position < source.length) {
                value = when (source[position]) {
                    '+' -> { position++; value + parseTerm() }
                    '-' -> { position++; value - parseTerm() }
                    else -> return value
                }
            }
            return value
        }

        private fun parseTerm(): Double {
            var value = parseUnary()
            while (position < source.length) {
                value = when (source[position]) {
                    '*' -> { position++; value * parseUnary() }
                    '/' -> {
                        position++
                        val divisor = parseUnary()
                        require(divisor != 0.0) { "Cannot divide by zero." }
                        value / divisor
                    }
                    else -> return value
                }
            }
            return value
        }

        private fun parseUnary(): Double {
            if (position < source.length && source[position] == '+') { position++; return parseUnary() }
            if (position < source.length && source[position] == '-') { position++; return -parseUnary() }
            return parseFactor()
        }

        private fun parseFactor(): Double {
            if (position < source.length && source[position] == '(') {
                position++
                val value = parseExpression()
                require(position < source.length && source[position] == ')') { "Missing closing parenthesis." }
                position++
                return value
            }
            val start = position
            var dotSeen = false
            while (position < source.length) {
                val c = source[position]
                if (c.isDigit()) position++
                else if (c == '.' && !dotSeen) { dotSeen = true; position++ }
                else break
            }
            require(position > start) { "Expected a number at position ${position + 1}." }
            return source.substring(start, position).toDoubleOrNull() ?: error("Invalid number.")
        }
    }
}
