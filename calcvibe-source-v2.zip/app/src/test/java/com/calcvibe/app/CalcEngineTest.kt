package com.calcvibe.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcEngineTest {
    @Test fun respectsOperatorPrecedence() {
        assertEquals(14.0, CalcEngine.evaluateExpression("2+3*4"), 0.000001)
    }

    @Test fun supportsParentheses() {
        assertEquals(20.0, CalcEngine.evaluateExpression("(2+3)*4"), 0.000001)
    }

    @Test fun percentOnAdditionUsesCalculatorConvention() {
        assertEquals(220.0, CalcEngine.evaluateExpression("200+10%"), 0.000001)
    }

    @Test fun supportsCurrencyModes() {
        try {
            CalcEngine.currencyCode = "USD"
            assertTrue(CalcEngine.money(111000.0).contains("$111,000"))
            CalcEngine.currencyCode = "INR"
            assertTrue(CalcEngine.money(111000.0).contains("₹1,11,000"))
        } finally {
            CalcEngine.currencyCode = "INR"
        }
    }

    @Test fun rejectsDivisionByZero() {
        try {
            CalcEngine.evaluateExpression("5/0")
            throw AssertionError("Expected division by zero to be rejected")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message!!.contains("divide by zero", ignoreCase = true))
        }
    }

    @Test fun understandsIndianTaxPrompt() {
        CalcEngine.currencyCode = "INR"
        val answer = CalcEngine.solveNaturalLanguage("1 lakh 11% tax")
        assertTrue(answer.details.contains("₹11,000"))
        assertTrue(answer.details.contains("₹1,11,000"))
    }

    @Test fun understandsDiscountPrompt() {
        CalcEngine.currencyCode = "INR"
        val answer = CalcEngine.solveNaturalLanguage("20% discount on 1500")
        assertTrue(answer.details.contains("₹300"))
        assertTrue(answer.details.contains("₹1,200"))
    }

    @Test fun computesSimpleInterest() {
        CalcEngine.currencyCode = "INR"
        val answer = CalcEngine.solveNaturalLanguage("1 lakh at 11% simple interest for 2 years")
        assertTrue(answer.details.contains("₹22,000"))
        assertTrue(answer.details.contains("₹1,22,000"))
    }

    @Test fun computesEmi() {
        val answer = CalcEngine.solveNaturalLanguage("EMI for 500000 at 9% for 5 years")
        assertTrue(answer.details.contains("Monthly EMI"))
        assertTrue(answer.numericValue!! > 0)
    }

    @Test fun taxShowsTaxAndGrandTotal() {
        CalcEngine.currencyCode = "USD"
        val answer = CalcEngine.tax(100000.0, 11.0)
        assertTrue(answer.details.contains("$11,000"))
        assertTrue(answer.details.contains("$111,000"))
    }

    @Test fun discountCannotProduceUnexpectedNegativeResult() {
        CalcEngine.currencyCode = "INR"
        val answer = CalcEngine.discount(1500.0, 20.0)
        assertTrue(answer.details.contains("₹300"))
        assertTrue(answer.details.contains("₹1,200"))
    }

    @Test fun compoundInterestAssumesAnnualCompounding() {
        CalcEngine.currencyCode = "USD"
        val answer = CalcEngine.compoundInterest(100000.0, 10.0, 2.0)
        assertEquals(121000.0, answer.numericValue!!, 0.000001)
    }

    @Test fun zeroInterestEmiDividesPrincipalAcrossMonths() {
        CalcEngine.currencyCode = "USD"
        val answer = CalcEngine.emi(12000.0, 0.0, 1.0)
        assertEquals(1000.0, answer.numericValue!!, 0.000001)
    }

    @Test fun calculatorRejectsAnEmptyExpression() {
        try {
            CalcEngine.evaluateExpression("")
            throw AssertionError("Expected empty expression to be rejected")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message!!.contains("Enter a calculation"))
        }
    }

    @Test fun understandsSpokenDivision() {
        val answer = CalcEngine.solveNaturalLanguage("what is 100 divided by 5")
        assertEquals(20.0, answer.numericValue!!, 0.000001)
    }
}
